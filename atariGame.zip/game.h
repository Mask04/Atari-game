#ifndef GAME_H
#define GAME_H
#include "game.c"
#endif